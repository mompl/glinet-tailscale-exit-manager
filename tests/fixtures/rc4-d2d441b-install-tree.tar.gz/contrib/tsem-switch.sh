#!/bin/sh
# GL.iNet hardware-switch hook for tsem. Thin wrapper: the ONLY thing it does is
# call the central controller (`tsem set ... --source hw --no-wait`). No firewall, no tailscale.
#
# The calling convention of /etc/gl-switch.d scripts must be verified on the device.
# This hook accepts the first argument (or $ACTION) as on|off|1|0|true|false and does
# NOTHING for anything else (fail-safe: unknown input never changes the state).
#
# Trace mode: `echo trace > /etc/tsem/hook.mode` logs the arguments/environment names
# to syslog and changes NOTHING. Use it once on the real device to learn how the
# firmware calls the script, then remove the file.

MODE_FILE=${TSEM_HOOK_MODE_FILE:-/etc/tsem/hook.mode}
TSEM_BIN=${TSEM_BIN:-/usr/sbin/tsem}
arg=${1:-${ACTION:-}}

if [ -r "$MODE_FILE" ] && [ "$(head -n 1 "$MODE_FILE" 2>/dev/null)" = trace ]; then
	logger -t tsem-hook "TRACE args='$*' ACTION='${ACTION:-}' BUTTON='${BUTTON:-}' env=$(env | cut -d= -f1 | tr '\n' ' ')"
	exit 0
fi

case $arg in
on | ON | 1 | true | german) mode=german ;;
off | OFF | 0 | false | direct) mode=direct ;;
*)
	logger -t tsem-hook "ignored unknown switch argument '$arg'"
	exit 0
	;;
esac
# Remember what the firmware reported (tmpfs, lost at reboot: after a reboot the position is "unknown" until the
# next flip, which is the truth: software cannot read the physical position). `tsem status` shows it as hw_state.
case $mode in german) _hw=on ;; *) _hw=off ;; esac
_hwd=${TSEM_RUN_DIR:-/var/run/tsem}
mkdir -p "$_hwd" 2>/dev/null && printf '%s %s\n' "$(date +%s)" "$_hw" >"$_hwd/hw_event.new" 2>/dev/null && mv -f "$_hwd/hw_event.new" "$_hwd/hw_event" 2>/dev/null
# Synchronous on purpose: events must reach the controller IN ORDER ("last user action wins").
# --no-wait only records the intent and applies the immediate guard (no probing), so this takes
# well under a second; the daemon does the slow part. A timeout keeps a hung controller from
# blocking the firmware's handler forever.
if timeout 1 true >/dev/null 2>&1; then
	timeout 30 "$TSEM_BIN" set "$mode" --source hw --no-wait >/dev/null 2>&1
else
	"$TSEM_BIN" set "$mode" --source hw --no-wait >/dev/null 2>&1
fi
exit 0
